# Quiver Evidence

- Command: `/opt/homebrew/Cellar/node@22/22.22.2_2/bin/node .quiver/evidence/a06-root-probes-01.cjs`
- Exit code: 0
- Duration ms: 283
- Started at: 2026-09-12T23:58:03.243Z
- Finished at: 2026-09-12T23:58:03.526Z
- Signal: -
- Output truncated: no

## Stdout

````text
{"source":"store.js","sha256":"058d2d5bd820532b8d7d6df959a982ea5c4e90a6e77e5a02155064608856edc6"}
{"source":"vault.js","sha256":"f6a36cef219c5e0e62329c5bc79fbc75379736555395f863f9b99b37ef753f00"}
{"probe":"protected-git-destination","code":"UNSAFE_PATH","wrote_inside_git":false}
{"probe":"destination-changes-during-authorization","code":"UNSAFE_PATH","wrote_outside_project":false}
{"probe":"snapshot-changes-during-authorization","code":"OK","append_code":"OK","advertised_revision":1,"canonical_revision":1,"missing_exported_records":[]}

````

## Stderr

````text

````
