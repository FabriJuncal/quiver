# Quiver Evidence

- Command: `/opt/homebrew/Cellar/node@22/22.22.2_2/bin/node bin/create-quiver.js brain add --json`
- Exit code: 2
- Duration ms: 188
- Started at: 2026-09-13T00:06:39.253Z
- Finished at: 2026-09-13T00:06:39.443Z
- Signal: -
- Output truncated: no

## Stdout

````text
{
  "schema_version": 1,
  "status": "blocked",
  "code": "VALIDATION_FAILED",
  "data": null,
  "errors": [
    {
      "code": "VALIDATION_FAILED",
      "message": "Brain command arguments are invalid."
    }
  ],
  "evidence_status": "failed"
}

````

## Stderr

````text

````
