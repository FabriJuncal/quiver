# Quiver Evidence

- Command: `/opt/homebrew/opt/node@22/bin/node --test tests/lib/brain-store.test.js tests/commands/init-profiles.test.js`
- Exit code: 0
- Duration ms: 67569
- Started at: 2026-09-12T23:47:42.645Z
- Finished at: 2026-09-12T23:48:50.214Z
- Signal: -
- Output truncated: no

## Stdout

````text
TAP version 13
# Subtest: init --dry-run prints the planned layout and does not write files
ok 1 - init --dry-run prints the planned layout and does not write files
  ---
  duration_ms: 147.476458
  type: 'test'
  ...
# Subtest: legacy --name alias supports dry-run without writing files
ok 2 - legacy --name alias supports dry-run without writing files
  ---
  duration_ms: 143.60275
  type: 'test'
  ...
# Subtest: unsupported subcommands fail clearly instead of initializing a project
ok 3 - unsupported subcommands fail clearly instead of initializing a project
  ---
  duration_ms: 151.523958
  type: 'test'
  ...
# Subtest: init --dry-run reports requested profiles and optional assets
ok 4 - init --dry-run reports requested profiles and optional assets
  ---
  duration_ms: 422.4635
  type: 'test'
  ...
# Subtest: init --interactive resolves guided choices without writing by itself
ok 5 - init --interactive resolves guided choices without writing by itself
  ---
  duration_ms: 3.103959
  type: 'test'
  ...
# Subtest: init --interactive keeps or changes existing project language without dropping config keys
ok 6 - init --interactive keeps or changes existing project language without dropping config keys
  ---
  duration_ms: 8.416459
  type: 'test'
  ...
# Subtest: init --interactive dry-run resolves intended language without writing config
ok 7 - init --interactive dry-run resolves intended language without writing config
  ---
  duration_ms: 3.181583
  type: 'test'
  ...
# Subtest: init --interactive rejects non-TTY automation with explicit flag guidance
ok 8 - init --interactive rejects non-TTY automation with explicit flag guidance
  ---
  duration_ms: 0.991
  type: 'test'
  ...
# Subtest: init rejects incompatible profile flags before writing files
ok 9 - init rejects incompatible profile flags before writing files
  ---
  duration_ms: 140.768458
  type: 'test'
  ...
# Subtest: init command without dry-run writes the default clean AI-first layout
ok 10 - init command without dry-run writes the default clean AI-first layout
  ---
  duration_ms: 1996.885833
  type: 'test'
  ...
# Subtest: explicit init preserves an existing empty Brain byte-for-byte
ok 11 - explicit init preserves an existing empty Brain byte-for-byte
  ---
  duration_ms: 3993.610542
  type: 'test'
  ...
# Subtest: init generated human docs follow --lang and keep machine artifacts stable
ok 12 - init generated human docs follow --lang and keep machine artifacts stable
  ---
  duration_ms: 4113.013709
  type: 'test'
  ...
# Subtest: init uses existing project language config for generated docs without --lang
ok 13 - init uses existing project language config for generated docs without --lang
  ---
  duration_ms: 1968.189916
  type: 'test'
  ...
# Subtest: init --minimal writes only the essential onboarding contract
ok 14 - init --minimal writes only the essential onboarding contract
  ---
  duration_ms: 2042.856
  type: 'test'
  ...
# Subtest: init --full preserves the historical compatibility layout explicitly
ok 15 - init --full preserves the historical compatibility layout explicitly
  ---
  duration_ms: 2400.567458
  type: 'test'
  ...
# Subtest: init --legacy-scripts writes compatibility wrappers and package scripts without full extras
ok 16 - init --legacy-scripts writes compatibility wrappers and package scripts without full extras
  ---
  duration_ms: 1961.952333
  type: 'test'
  ...
# Subtest: init --include-templates exports packaged templates under .quiver/templates only
ok 17 - init --include-templates exports packaged templates under .quiver/templates only
  ---
  duration_ms: 2200.231625
  type: 'test'
  ...
# Subtest: init preserves existing project files by default
ok 18 - init preserves existing project files by default
  ---
  duration_ms: 1915.136875
  type: 'test'
  ...
# Subtest: init merges root gitignore defaults without deleting existing entries
ok 19 - init merges root gitignore defaults without deleting existing entries
  ---
  duration_ms: 1853.143417
  type: 'test'
  ...
# Subtest: migrate --yes reports legacy layout paths and preserves existing legacy files
ok 20 - migrate --yes reports legacy layout paths and preserves existing legacy files
  ---
  duration_ms: 4158.3645
  type: 'test'
  ...
# Subtest: migrate without --yes is safe and actionable in no-TTY automation
ok 21 - migrate without --yes is safe and actionable in no-TTY automation
  ---
  duration_ms: 8073.683
  type: 'test'
  ...
# Subtest: migrate cancellation leaves the tree unchanged before side effects
ok 22 - migrate cancellation leaves the tree unchanged before side effects
  ---
  duration_ms: 4034.219041
  type: 'test'
  ...
# Subtest: migrate --dry-run reports planned changes without writing
ok 23 - migrate --dry-run reports planned changes without writing
  ---
  duration_ms: 4238.189875
  type: 'test'
  ...
# Subtest: migrate --dry-run supports Spanish human output without translating commands
ok 24 - migrate --dry-run supports Spanish human output without translating commands
  ---
  duration_ms: 4386.952083
  type: 'test'
  ...
# Subtest: migration JSON is no-write on preview, verified on apply, idempotent on reapply, and rollback-safe
ok 25 - migration JSON is no-write on preview, verified on apply, idempotent on reapply, and rollback-safe
  ---
  duration_ms: 16960.994792
  type: 'test'
  ...
# Subtest: empty Brain initialization is stable and idempotent
ok 26 - empty Brain initialization is stable and idempotent
  ---
  duration_ms: 45.856417
  type: 'test'
  ...
# Subtest: protected operations do not lazily recreate an absent Brain
ok 27 - protected operations do not lazily recreate an absent Brain
  ---
  duration_ms: 3.538792
  type: 'test'
  ...
# Subtest: append supports every typed record and derives immutable metadata
ok 28 - append supports every typed record and derives immutable metadata
  ---
  duration_ms: 451.588042
  type: 'test'
  ...
# Subtest: supersession preserves history, derives active validity, and enforces authority precedence
ok 29 - supersession preserves history, derives active validity, and enforces authority precedence
  ---
  duration_ms: 107.225875
  type: 'test'
  ...
# Subtest: CAS and idempotency replay are enforced in the normative order
ok 30 - CAS and idempotency replay are enforced in the normative order
  ---
  duration_ms: 78.454833
  type: 'test'
  ...
# Subtest: unverified, foreign, and under-granted actors fail before canonical writes
ok 31 - unverified, foreign, and under-granted actors fail before canonical writes
  ---
  duration_ms: 45.378
  type: 'test'
  ...
# Subtest: secret, operational-state, unsafe-path, and unverifiable-fact inputs never persist
ok 32 - secret, operational-state, unsafe-path, and unverifiable-fact inputs never persist
  ---
  duration_ms: 32.01525
  type: 'test'
  ...
# Subtest: a valid digest for unrelated bytes cannot elevate an arbitrary verified fact
ok 33 - a valid digest for unrelated bytes cannot elevate an arbitrary verified fact
  ---
  duration_ms: 34.848333
  type: 'test'
  ...
# Subtest: the supported local v58 decision representation binds the exact approved artifact
ok 34 - the supported local v58 decision representation binds the exact approved artifact
  ---
  duration_ms: 0.52175
  type: 'test'
  ...
# Subtest: writer mutex returns a lock conflict without changing the store
ok 35 - writer mutex returns a lock conflict without changing the store
  ---
  duration_ms: 29.117584
  type: 'test'
  ...
# Subtest: concurrent appends either serialize or return an explicit lock conflict
ok 36 - concurrent appends either serialize or return an explicit lock conflict
  ---
  duration_ms: 63.584667
  type: 'test'
  ...
# Subtest: read-only v58 compatibility blocks every Brain writer before mutation
ok 37 - read-only v58 compatibility blocks every Brain writer before mutation
  ---
  duration_ms: 31.156
  type: 'test'
  ...
# Subtest: symlinked canonical record or operation directories cannot write outside the project
ok 38 - symlinked canonical record or operation directories cannot write outside the project
  ---
  duration_ms: 45.667042
  type: 'test'
  ...
# Subtest: a symlinked manifest target is rejected before any Brain mutation
ok 39 - a symlinked manifest target is rejected before any Brain mutation
  ---
  duration_ms: 21.690709
  type: 'test'
  ...
# Subtest: stale or corrupt index rebuilds only from the canonical manifest
ok 40 - stale or corrupt index rebuilds only from the canonical manifest
  ---
  duration_ms: 73.742709
  type: 'test'
  ...
# Subtest: validated journal recovery rolls forward an interrupted manifest commit
ok 41 - validated journal recovery rolls forward an interrupted manifest commit
  ---
  duration_ms: 76.873125
  type: 'test'
  ...
# Subtest: Cloud receipt fixture binds exact knowledge and preserves original decision provenance
ok 42 - Cloud receipt fixture binds exact knowledge and preserves original decision provenance
  ---
  duration_ms: 85.330416
  type: 'test'
  ...
# Subtest: Cloud receipt mismatch, unavailable source, and noncurrent state block before writes
ok 43 - Cloud receipt mismatch, unavailable source, and noncurrent state block before writes
  ---
  duration_ms: 90.275375
  type: 'test'
  ...
1..43
# tests 43
# suites 0
# pass 43
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 67503.012292

````

## Stderr

````text

````
