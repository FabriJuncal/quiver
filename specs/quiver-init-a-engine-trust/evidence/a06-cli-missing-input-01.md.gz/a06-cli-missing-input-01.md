# Quiver Evidence

- Command: `/opt/homebrew/Cellar/node@22/22.22.2_2/bin/node bin/create-quiver.js brain add --json`
- Exit code: 1
- Duration ms: 176
- Started at: 2026-09-13T00:03:56.207Z
- Finished at: 2026-09-13T00:03:56.383Z
- Signal: -
- Output truncated: no

## Stdout

````text

````

## Stderr

````text
create-quiver: brain add requires --input, --operation-id, and --expected-revision

````
