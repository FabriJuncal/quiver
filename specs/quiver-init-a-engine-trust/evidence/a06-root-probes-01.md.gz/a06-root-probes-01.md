# Quiver Evidence

- Command: `/opt/homebrew/Cellar/node@22/22.22.2_2/bin/node .quiver/evidence/a06-root-probes-01.cjs`
- Exit code: 0
- Duration ms: 372
- Started at: 2026-09-12T23:56:01.838Z
- Finished at: 2026-09-12T23:56:02.211Z
- Signal: -
- Output truncated: no

## Stdout

````text
{"source":"store.js","sha256":"c97e9822b55b2852f7203c73cb4a088296246dcdb25d3f727d461ddf85c28f87"}
{"source":"vault.js","sha256":"cf438eb8f049954d0d8ffbc4f1d99ab0fa5562822052c342e4b68ff13982c0f4"}
{"probe":"protected-git-destination","code":"OK","wrote_inside_git":true}
{"probe":"destination-changes-during-authorization","code":"OK","wrote_outside_project":true}
{"probe":"snapshot-changes-during-authorization","code":"OK","append_code":"OK","advertised_revision":0,"canonical_revision":1,"missing_exported_records":["knowledge:concurrent"]}

````

## Stderr

````text

````
