# Quiver Evidence

- Command: `/opt/homebrew/opt/node@22/bin/node --test tests/lib/draft-integrity.test.js tests/lib/approvals.test.js tests/lib/brain-store.test.js tests/lib/init-layout.test.js`
- Exit code: 0
- Duration ms: 2073
- Started at: 2026-09-12T23:46:40.832Z
- Finished at: 2026-09-12T23:46:42.905Z
- Signal: -
- Output truncated: no

## Stdout

````text
TAP version 13
# Subtest: planner approvals persist draft and approved metadata with status summaries
ok 1 - planner approvals persist draft and approved metadata with status summaries
  ---
  duration_ms: 79.512708
  type: 'test'
  ...
# Subtest: planner approvals keep multiple drafts and only approve the current version
ok 2 - planner approvals keep multiple drafts and only approve the current version
  ---
  duration_ms: 127.092708
  type: 'test'
  ...
# Subtest: legacy planner approval writer rejects approved-with-conditions without creating approved.md
ok 3 - legacy planner approval writer rejects approved-with-conditions without creating approved.md
  ---
  duration_ms: 53.878583
  type: 'test'
  ...
# Subtest: planner approval candidates expose current draft, history, and safe previews
ok 4 - planner approval candidates expose current draft, history, and safe previews
  ---
  duration_ms: 106.442042
  type: 'test'
  ...
# Subtest: planner approvals block unapproved or stale inputs before later phases
ok 5 - planner approvals block unapproved or stale inputs before later phases
  ---
  duration_ms: 201.194541
  type: 'test'
  ...
# Subtest: planner drafts persist exact artifact and input byte digests
ok 6 - planner drafts persist exact artifact and input byte digests
  ---
  duration_ms: 62.816083
  type: 'test'
  ...
# Subtest: digest-bound projection rejects artifact and input tampering without approving
ok 7 - digest-bound projection rejects artifact and input tampering without approving
  ---
  duration_ms: 58.811292
  type: 'test'
  ...
# Subtest: content loss persists a corrupted immutable candidate without replacing current or approval history
ok 8 - content loss persists a corrupted immutable candidate without replacing current or approval history
  ---
  duration_ms: 105.110959
  type: 'test'
  ...
# Subtest: unsupported free text remains inspectable but never becomes current automatically
ok 9 - unsupported free text remains inspectable but never becomes current automatically
  ---
  duration_ms: 33.165458
  type: 'test'
  ...
# Subtest: draft projection journal rolls forward deterministically from every committed crash point
ok 10 - draft projection journal rolls forward deterministically from every committed crash point
  ---
  duration_ms: 423.999166
  type: 'test'
  ...
# Subtest: a crash before journal publication leaves an immutable orphan and unchanged projections
ok 11 - a crash before journal publication leaves an immutable orphan and unchanged projections
  ---
  duration_ms: 80.3985
  type: 'test'
  ...
# Subtest: corrupt metadata, duplicate versions, competing writers, and unexpected recovery digests fail closed
ok 12 - corrupt metadata, duplicate versions, competing writers, and unexpected recovery digests fail closed
  ---
  duration_ms: 168.42675
  type: 'test'
  ...
# Subtest: v1 readers reject inconsistent selection, invalid history, tampered projection, and unsafe candidate paths
ok 13 - v1 readers reject inconsistent selection, invalid history, tampered projection, and unsafe candidate paths
  ---
  duration_ms: 283.3945
  type: 'test'
  ...
# Subtest: draft recovery respects governance read-only mode without changing marker or projections
ok 14 - draft recovery respects governance read-only mode without changing marker or projections
  ---
  duration_ms: 52.886833
  type: 'test'
  ...
# Subtest: project file byte reader rejects path traversal outside the project root
ok 15 - project file byte reader rejects path traversal outside the project root
  ---
  duration_ms: 0.486
  type: 'test'
  ...
# Subtest: project file byte reader rejects symlinks that resolve outside the project root
ok 16 - project file byte reader rejects symlinks that resolve outside the project root
  ---
  duration_ms: 0.768167
  type: 'test'
  ...
# Subtest: project file byte reader rejects in-project symlink aliases
ok 17 - project file byte reader rejects in-project symlink aliases
  ---
  duration_ms: 0.417417
  type: 'test'
  ...
# Subtest: empty Brain initialization is stable and idempotent
ok 18 - empty Brain initialization is stable and idempotent
  ---
  duration_ms: 51.342458
  type: 'test'
  ...
# Subtest: protected operations do not lazily recreate an absent Brain
ok 19 - protected operations do not lazily recreate an absent Brain
  ---
  duration_ms: 3.417125
  type: 'test'
  ...
# Subtest: append supports every typed record and derives immutable metadata
ok 20 - append supports every typed record and derives immutable metadata
  ---
  duration_ms: 659.962917
  type: 'test'
  ...
# Subtest: supersession preserves history, derives active validity, and enforces authority precedence
ok 21 - supersession preserves history, derives active validity, and enforces authority precedence
  ---
  duration_ms: 146.575083
  type: 'test'
  ...
# Subtest: CAS and idempotency replay are enforced in the normative order
ok 22 - CAS and idempotency replay are enforced in the normative order
  ---
  duration_ms: 100.77075
  type: 'test'
  ...
# Subtest: unverified, foreign, and under-granted actors fail before canonical writes
ok 23 - unverified, foreign, and under-granted actors fail before canonical writes
  ---
  duration_ms: 56.181417
  type: 'test'
  ...
# Subtest: secret, operational-state, unsafe-path, and unverifiable-fact inputs never persist
ok 24 - secret, operational-state, unsafe-path, and unverifiable-fact inputs never persist
  ---
  duration_ms: 50.621041
  type: 'test'
  ...
# Subtest: a valid digest for unrelated bytes cannot elevate an arbitrary verified fact
ok 25 - a valid digest for unrelated bytes cannot elevate an arbitrary verified fact
  ---
  duration_ms: 45.734208
  type: 'test'
  ...
# Subtest: the supported local v58 decision representation binds the exact approved artifact
ok 26 - the supported local v58 decision representation binds the exact approved artifact
  ---
  duration_ms: 0.547042
  type: 'test'
  ...
# Subtest: writer mutex returns a lock conflict without changing the store
ok 27 - writer mutex returns a lock conflict without changing the store
  ---
  duration_ms: 36.327708
  type: 'test'
  ...
# Subtest: concurrent appends either serialize or return an explicit lock conflict
ok 28 - concurrent appends either serialize or return an explicit lock conflict
  ---
  duration_ms: 97.481458
  type: 'test'
  ...
# Subtest: read-only v58 compatibility blocks every Brain writer before mutation
ok 29 - read-only v58 compatibility blocks every Brain writer before mutation
  ---
  duration_ms: 43.712667
  type: 'test'
  ...
# Subtest: symlinked canonical record or operation directories cannot write outside the project
ok 30 - symlinked canonical record or operation directories cannot write outside the project
  ---
  duration_ms: 60.384167
  type: 'test'
  ...
# Subtest: a symlinked manifest target is rejected before any Brain mutation
ok 31 - a symlinked manifest target is rejected before any Brain mutation
  ---
  duration_ms: 33.222584
  type: 'test'
  ...
# Subtest: stale or corrupt index rebuilds only from the canonical manifest
ok 32 - stale or corrupt index rebuilds only from the canonical manifest
  ---
  duration_ms: 104.46025
  type: 'test'
  ...
# Subtest: validated journal recovery rolls forward an interrupted manifest commit
ok 33 - validated journal recovery rolls forward an interrupted manifest commit
  ---
  duration_ms: 101.287167
  type: 'test'
  ...
# Subtest: Cloud receipt fixture binds exact knowledge and preserves original decision provenance
ok 34 - Cloud receipt fixture binds exact knowledge and preserves original decision provenance
  ---
  duration_ms: 113.333375
  type: 'test'
  ...
# Subtest: Cloud receipt mismatch, unavailable source, and noncurrent state block before writes
ok 35 - Cloud receipt mismatch, unavailable source, and noncurrent state block before writes
  ---
  duration_ms: 105.853625
  type: 'test'
  ...
# Subtest: draft lifecycle vocabulary is explicit and bounded
ok 36 - draft lifecycle vocabulary is explicit and bounded
  ---
  duration_ms: 2.077417
  type: 'test'
  ...
# Subtest: markdown extraction recognizes requirement, acceptance, slice, and fenced JSON identities
ok 37 - markdown extraction recognizes requirement, acceptance, slice, and fenced JSON identities
  ---
  duration_ms: 1.546625
  type: 'test'
  ...
# Subtest: structured extraction supports exact collections, references, and v58 acceptance arrays
ok 38 - structured extraction supports exact collections, references, and v58 acceptance arrays
  ---
  duration_ms: 0.441417
  type: 'test'
  ...
# Subtest: preservation compares structural identity rather than word count
ok 39 - preservation compares structural identity rather than word count
  ---
  duration_ms: 0.298958
  type: 'test'
  ...
# Subtest: missing identity and required collection are diagnosed as corruption
ok 40 - missing identity and required collection are diagnosed as corruption
  ---
  duration_ms: 0.214916
  type: 'test'
  ...
# Subtest: explicit deletion is accepted only when the exact identity and references are removed
ok 41 - explicit deletion is accepted only when the exact identity and references are removed
  ---
  duration_ms: 0.424333
  type: 'test'
  ...
# Subtest: duplicates, broken references, malformed structured content, and free text fail closed
ok 42 - duplicates, broken references, malformed structured content, and free text fail closed
  ---
  duration_ms: 0.318875
  type: 'test'
  ...
# Subtest: resolveInitProfile selects default, minimal, and full profiles
ok 43 - resolveInitProfile selects default, minimal, and full profiles
  ---
  duration_ms: 0.82575
  type: 'test'
  ...
# Subtest: normalizeInitLayoutOptions rejects mutually exclusive profiles
ok 44 - normalizeInitLayoutOptions rejects mutually exclusive profiles
  ---
  duration_ms: 0.254875
  type: 'test'
  ...
# Subtest: buildInitLayout creates a default AI-first plan without legacy visible roots
ok 45 - buildInitLayout creates a default AI-first plan without legacy visible roots
  ---
  duration_ms: 2.763042
  type: 'test'
  ...
# Subtest: buildInitLayout reports preserved files instead of overwriting them
ok 46 - buildInitLayout reports preserved files instead of overwriting them
  ---
  duration_ms: 2.67275
  type: 'test'
  ...
# Subtest: buildInitLayout includes compatibility assets for full profile
ok 47 - buildInitLayout includes compatibility assets for full profile
  ---
  duration_ms: 0.704417
  type: 'test'
  ...
# Subtest: buildInitLayout includes optional legacy scripts and template export only when requested
ok 48 - buildInitLayout includes optional legacy scripts and template export only when requested
  ---
  duration_ms: 0.662042
  type: 'test'
  ...
# Subtest: formatInitLayoutPlan prints core dry-run sections
ok 49 - formatInitLayoutPlan prints core dry-run sections
  ---
  duration_ms: 0.639459
  type: 'test'
  ...
# Subtest: formatInitLayoutPlan reports planned language config writes
ok 50 - formatInitLayoutPlan reports planned language config writes
  ---
  duration_ms: 1.23
  type: 'test'
  ...
# Subtest: default generated package scripts target supported CLI commands
ok 51 - default generated package scripts target supported CLI commands
  ---
  duration_ms: 0.567458
  type: 'test'
  ...
1..51
# tests 51
# suites 0
# pass 51
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 2002.231333

````

## Stderr

````text

````
