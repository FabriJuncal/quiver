# Quiver Evidence

- Command: `/opt/homebrew/Cellar/node@22/22.22.2_2/bin/node bin/create-quiver.js brain delete --contract-version 2 --dry-run --json`
- Exit code: 1
- Duration ms: 150
- Started at: 2026-09-13T00:03:56.386Z
- Finished at: 2026-09-13T00:03:56.536Z
- Signal: -
- Output truncated: no

## Stdout

````text

````

## Stderr

````text
create-quiver: unsupported contract version; expected 1

````
